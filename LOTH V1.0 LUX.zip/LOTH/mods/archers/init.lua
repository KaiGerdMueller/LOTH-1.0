-- Minetest mod: creepers
-- (c) Kai Gerd Müller
-- See README.txt for licensing and other information.
local g_force=10
--[[
p1
p2
archer
damage[]
penetration[]
maxvel
]]
local function get_nearest_enemy_orc(self,pos,radius,fucking_punchtest)
	local min_dist = radius+1
	local target = false
	for _,entity in ipairs(minetest.get_objects_inside_radius(pos,25)) do
		local luaent = entity:get_luaentity()
		local name = entity:get_player_name()
		if (luaent and (not luaent.orc)) or (entity:is_player() and(
		(not orcishplayers[name])
		 or (orcishlaw[name]  and orcishlaw[name] > 0  )
		)) then
		local p = entity:getpos()
		local dist = vector.distance(pos,p)
				if default_do_not_punch_this_stuff(luaent) and (minetest.line_of_sight(vector.add(pos,{x=0,y=5,z=0}),vector.add(p,{x=0,y=5,z=0}), 2) == true or minetest.line_of_sight(pos,p, 2) == true --[[or minetest.line_of_sight(vector.add(pos,{x=0,y=1,z=0}),vector.add(p,{x=0,y=1,z=0}), 2) == true]]) and dist < min_dist then
			min_dist = dist
				target = entity
		end
		end
	end
if target and ((not fucking_punchtest) or minetest.line_of_sight(target:getpos(),pos,2)) then
return target
else
return target
end
end
local function get_nearest_enemy_hudwel(self,pos,radius)
	local min_dist = radius+1
	local target = false
	for _,entity in ipairs(minetest.get_objects_inside_radius(pos,25)) do
		local luaent = entity:get_luaentity()
--		db(hudwelshlaw)
		local name = entity:get_player_name()
		if (luaent and (not luaent.hudwel)) or (entity:is_player() and(
		(not hudwelshplayers[name])
		 or (hudwelshlaw[name]  and hudwelshlaw[name] > 0  )
		)) then
		local p = entity:getpos()
		local dist = vector.distance(pos,p)
				if default_do_not_punch_this_stuff(luaent) and (minetest.line_of_sight(vector.add(pos,{x=0,y=5,z=0}),vector.add(p,{x=0,y=5,z=0}), 2) == true or minetest.line_of_sight(pos,p, 2) == true --[[or minetest.line_of_sight(vector.add(pos,{x=0,y=1,z=0}),vector.add(p,{x=0,y=1,z=0}), 2) == true]]) and dist < min_dist then
			min_dist = dist
				target = entity
		end
		end
	end
if target and ((not fucking_punchtest) or minetest.line_of_sight(target:getpos(),pos,2)) then
return target
else
return false
end
end
local function calculate_archingvec(vec,speed)
local lenght = math.sqrt((vec.x*vec.x)+(vec.z*vec.z))
local v = math.sqrt((lenght+(vec.y*g_force/lenght))*g_force)
if v <= speed then
vec.y=lenght
return vector.multiply(vector.normalize(vec),v)
else
return false
end
end
local function standardarch(def)
	local avec = calculate_archingvec(vector.subtract(def.p2,def.p1),def.maxvel)
	if avec then
	db(avec)
	local arrow = minetest.add_entity(def.p1,"lotharrows:arrow")
	local luaent = arrow:get_luaentity()
	luaent.shooter = def.archer
	luaent.damage = def.damage or 10
	arrow:setvelocity(avec)
	arrow:setacceleration({x=0,y=-10,z=0})
	arrow:setyaw(math.atan2(avec.z,avec.x)+math.pi/2)
	return math.atan2(avec.z,avec.x)
	end
	return avec
end
local function jump_needet(size,pos)
pos.y = (pos.y-size)+0.5
local r = false
for x = -1,1 do
for z = -1,1 do
if minetest.registered_nodes[minetest.get_node({x = pos.x+x,y=pos.y,z=pos.z+z}).name].walkable then
r = true
end
end
end
return r
end
local function animate(self, t)
	if t == 1 and self.canimation ~= 1 then
		self.object:set_animation({
			x = 0,
			y = 80},
			30, 0)
		self.canimation = 1
	elseif t == 2 and self.canimation ~= 2 then
		self.object:set_animation({x = 200,y = 220},30, 0)
		self.canimation = 2
	--walkmine
	elseif t == 3 and self.canimation ~= 3 then
		self.object:set_animation({x = 168,y = 188},30, 0)
		self.canimation = 3
	--walk
	elseif t == 4 and self.canimation ~= 4 then
		self.object:set_animation({x = 189,y = 199},30, 0)
		self.canimation = 4
	--walk
	end
end
local function get_nearest_enemy(self,pos,radius)
	local min_dist = radius+1
	local target = false
	for _,entity in ipairs(minetest.get_objects_inside_radius(pos,radius)) do
		luaent = entity:get_luaentity()
		if (entity:is_player() and entity:get_player_name() ~= self.owner_name)  or (luaent and (luaent.guard and not luaent.owner_name == self.owner_name) and not luaent.arrow) or ((not luaent) and not entity:is_player()) or (luaent and (not luaent.guard) and (not luaent.arrow)) then
		local p = entity:getpos()
		local dist = vector.distance(pos,p)
		if dist < min_dist then
			min_dist = dist
			min_player = player
			target = entity
		end
		end
	end
return target
end
local function get_nearest_player(self,pos,radius)
	local min_dist = radius+1
	local target = false
	for _,entity in ipairs(minetest.get_objects_inside_radius(pos,25)) do
		if entity:is_player() then
			local p = entity:getpos()
			local dist = vector.distance(pos,p)
			if dist < min_dist then
				min_dist = dist
				min_player = player
					target = entity
			end
		end
	end
if target then
return target:get_player_name()
else
return target
end
end
local calctarget  = function(table)
	if math.random(1,table.chanche) == 1 or not (table.target.x and table.target.y and table.target.z) then
		table.target = vector.multiply(vector.normalize({x= math.random(1,2)-1.5,y = 0,z= math.random(1,2)-1.5}),table.speed)
	end
	return table
end
local function register_archer(def)
	local defbox = def.size/2
	minetest.register_entity("archers:" .. def.name,{
		initial_properties = {
			name = def.name,
			hp_min = def.max_hp,
			hp_max = def.max_hp,
			visual_size = {x = def.size, y = def.size, z = def.size},
			visual = "mesh",
			mesh = "character20.b3d",
			textures = {"mobbow.png",def.name .. ".png"},
			collisionbox = {-defbox, -def.size, -defbox, defbox, def.size, defbox},
			physical = true
		},
		-- ON ACTIVATE --
		on_punch = lawbreak_on_punch,
		on_activate = function(self)
			self.walkaround = {target = {},speed = def.speed,chanche = 100,calc = calctarget}
			self.object:set_armor_groups({fleshy = def.armor or 100,level = 1})
			self.timer = 0
			self.lavadamagetimer = 0
			self.orc = def.orc
			self.hudwel = def.hudwel
			self.yaw=false
			self.jump = 0
			self.lawname = def.law
			self.guard = true
			self.object:setacceleration({x=0,y=-50,z=0})
		self.object:set_animation({
			x = 0,
			y = 80},
			30, 0)
			self.canimation = 1
		end,
		-- ON PUNCH --
		-- ON STEP --
		on_step = function(self, dtime)
			local pos = self.object:getpos()
			self.animation_set = true
			self.gravity = {x=0,y=-50,z=0}
			self.targetvektor = nil
			if self.timer < 1 then
			self.timer = self.timer+dtime
			end
			if self.lavadamagetimer < 1 then
			self.lavadamagetimer = self.lavadamagetimer + dtime
			elseif minetest.get_node(vector.subtract(pos,{x=0,y=0.5,z=0})).name == "default:lava_source" or minetest.get_node(vector.subtract(pos,{x=0,y=0.5,z=0})).name == "default:lava_flowing" then
			self.object:remove()
			else
			self.lavadamagetimer = 0
			end
			if self.timer >=1 then
			self.forcepunch = false
			self.yaw=false
			local target = def.get_nearest_enemy(self,pos,100)
			if target then
			local sarch=standardarch({
p1 = vector.add(pos,{x=0,y=1,z=0}),
p2 = target:getpos(),
archer = self.object,
damage = def.damage,
--penetration = def.penetration,
maxvel = def.maxvel})
			if sarch then
			self.yaw=sarch
			self.forcepunch = true
			end
			self.timer = 0
			end
			end

			if not self.targetvektor then
					self.walkaround = self.walkaround.calc(self.walkaround)
					self.targetvektor = self.walkaround.target
					self.nextanimation = 3
					self.animation_set = false
			end
			local velocity = self.object:getvelocity()
			self.jump = (self.jump +1)%10
			if self.targetvektor then
			if self.forcepunch then
				self.nextanimation = 2
			end
			if  minetest.get_node(pos).name == "default:water_source" then
				self.gravity = {x=0,y=0,z=0}
			end
			if  minetest.get_node(vector.add(pos,{x=0,y=1,z=0})).name == "default:water_source" then
				self.targetvektor.y = 1
			end
			if self.jump == 0 and --[[vector.distance(vector.new(),velocity)<def.speed/10 and velocity.y == 0 and minetest.registered_nodes[minetest.get_node(vector.add(pos,{x=0,y=-(def.size+0.5),z=0})).name].walkable]]jump_needet(def.size,pos) then
					stomp(self,1)		
			end
			self.object:setacceleration(self.gravity)
			self.object:setvelocity(self.targetvektor)
			else
				self.object:setvelocity({x=0,y=0,z=0})	
				if not self.forcepunch then	
				self.nextanimation = 1
				else
				self.nextanimation = 4
				end
			end
			animate(self,self.nextanimation)
			if( not self.yaw )then
			if( self.targetvektor )then
			self.object:setyaw(math.atan2(self.targetvektor.z,self.targetvektor.x)-math.pi/2)
			else
			self.object:setyaw(0)
			end
			else
			self.object:setyaw(self.yaw-math.pi/2)
			end
			if self.object:get_hp() > 0 then return end
			self.object:remove()
		end
	})
regular_humanoid_spawn_registry("archers:" .. def.name,def.spawn,def.chanche)
end

register_archer({
	damage = 3,
	--penetration = 3,
	maxvel = 100000,
	get_nearest_enemy = get_nearest_enemy_orc,
	name = "uruguay",
	orc = true,
	max_hp = 30,
	armor = 30,
	spawn = {"default:mordordust_mapgen","default:mordordust","default:angmarsnow"},
	chanche = 4000,
	size = 1,
	speed = 3,
	law = "orcishlaw"
})
register_archer({
	damage = 2,
	--penetration = 3,
	maxvel = 100000,
	get_nearest_enemy = get_nearest_enemy_orc,
	name = "orccharacter",
	orc = true,
	max_hp = 20,
	spawn = {"default:mordordust_mapgen","default:angmarsnow","default:mordordust","default:brownlandsdirt","default:fangorndirt"},
	chanche = 3000,
	size = 1,
	speed = 3,
	law = "orcishlaw"
})
register_archer({
	damage = 8,
	--penetration = 3,
	maxvel = 1000000,
	get_nearest_enemy = get_nearest_enemy_hudwel,
	name = "elf",
	hudwel = true,
	max_hp = 90,
	armor = 15,
	spawn = {"default:loriendirt"},
	chanche = 2000,
	size = 1,
	speed = 5,
	law = "hudwelshlaw"
})
register_archer({
	damage = 7,
	--penetration = 3,
	maxvel = 1000000,
	get_nearest_enemy = get_nearest_enemy_hudwel,
	name = "elfcharacter",
	hudwel = true,
	max_hp = 85,
	spawn = {"default:mirkwooddirt","default:loriendirt"},
	chanche = 3000,
	size = 1,
	speed = 5,
	law = "hudwelshlaw"
})
register_archer({
	damage = 6,
	--penetration = 3,
	maxvel = 1000000,
	get_nearest_enemy = get_nearest_enemy_hudwel,
	name = "human",
	hudwel = true,
	max_hp = 60,
	armor = 20,
	spawn = {"default:gondordirt","default:ithiliendirt"},
	chanche = 4000,
	size = 1,
	speed = 4,
	law = "hudwelshlaw"
})
register_archer({
	damage = 5,
	--penetration = 3,
	maxvel = 500000,
	get_nearest_enemy = get_nearest_enemy_hudwel,
	name = "humancharacter",
	hudwel = true,
	max_hp = 55,
	spawn = {"default:gondordirt","default:rohandirt","default:ithiliendirt"},
	chanche = 5000,
	size = 1,
	speed = 4,
	law = "hudwelshlaw"
})--[[
register_guard({
	damage = 10,
	name = "copper",
	max_hp = 40,
	size = 1,
	speed = 3
})
register_guard({
	damage = 11,
	name = "bronze",
	max_hp = 50,
	size = 1,
	speed = 3
})
register_guard({
	damage = 12,
	name = "obsidian",
	max_hp = 60,
	size = 1,
	speed = 3
})
register_guard({
	damage = 13,
	name = "gold",
	max_hp = 80,
	size = 1,
	speed = 3
})

register_guard({
	damage = 14,
	name = "mese",
	max_hp = 85,
	size = 1,
	speed = 3
})
register_guard({
	damage = 15,
	name = "diamond",
	max_hp = 90,
	size = 1,
	speed = 3
})]]



