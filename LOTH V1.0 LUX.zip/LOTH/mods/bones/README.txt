Minetest Game mod: bones
========================

License of source code:
-----------------------
Copyright (C) 2012 PilzAdam
Copyright (C) 2017 KGM Kai Gerd Müller <kai_gerd_mueller@gmx.de> (LOTH stuff)

WTFPL

License of media (textures and sounds)
--------------------------------------
Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
http://creativecommons.org/licenses/by-sa/3.0/

Authors of media files
----------------------
Bad_Command_
